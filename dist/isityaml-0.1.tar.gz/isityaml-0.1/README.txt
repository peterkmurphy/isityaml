This is the README.TXT for isityaml, a small Django module for 
testing files for conformance to YAML. You should know what to do with it. I.e.:

python setup.py install

All software associated with this setup script is copyright (c) 2009, 2010,
2011 Peter Murphy <peterkmurphy@gmail.com>, and released using a 3 clause 
Berkeley Software Distribution (BSD) license. See LICENSE.txt

To see it in action, look at:

http://www.pkmurphy.com.au/isityaml/




