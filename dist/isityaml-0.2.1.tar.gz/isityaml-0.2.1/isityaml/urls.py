from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^$', 'isityaml.views.index'),    
)
